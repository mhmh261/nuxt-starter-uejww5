set -e
echo -n "Setting up secrets... "

cp /init-secrets/* /secrets
if [[ $? -eq 0 ]]; then
  echo "done"
fi